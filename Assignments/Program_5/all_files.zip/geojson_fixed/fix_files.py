import json
import collections
import pprint as pp
import sys,os


file_list = []
file_list.append('/code/repos/4553-Spatial-DS/Private/playground/05_work_folder/geojson/airports.geojson')
file_list.append('/code/repos/4553-Spatial-DS/Private/playground/05_work_folder/geojson/earthquakes.geojson')
file_list.append('/code/repos/4553-Spatial-DS/Private/playground/05_work_folder/geojson/globalterrorism.geojson')
file_list.append('/code/repos/4553-Spatial-DS/Private/playground/05_work_folder/geojson/meteorite.geojson')
file_list.append('/code/repos/4553-Spatial-DS/Private/playground/05_work_folder/geojson/volcanos.geojson')
file_list.append('/code/repos/4553-Spatial-DS/Private/playground/05_work_folder/geojson/world_cities.geojson')

for file in file_list:

    f = open(file,"r")
    parts = file.split('/')
    name = parts[-1].split('.')[0] + '_fixed.geojson'
    print(name)
    o = open('/code/repos/4553-Spatial-DS/Private/playground/05_work_folder/geojson/'+name,'w')



    data = json.loads(f.read())

    for i in range(len(data)):
        if 'properties' in data[i]:
            for key,val in data[i]['properties'].items():
                if isinstance(val, (str, unicode)) and val.isnumeric():
                    data[i]['properties'][key] = int(val)


    o.write(json.dumps(data, sort_keys=False,indent=4, separators=(',', ': ')))
