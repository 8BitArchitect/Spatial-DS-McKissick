mongo world_data --eval "db.dropDatabase()"
mongoimport --db world_data --collection airports       --type json --file airports_fixed.geojson        --jsonArray
mongoimport --db world_data --collection countries      --type json --file countries_fixed.geojson       --jsonArray
mongoimport --db world_data --collection meteorites     --type json --file meteorite_fixed.geojson       --jsonArray
mongoimport --db world_data --collection volcanos       --type json --file volcanos_fixed.geojson        --jsonArray
mongoimport --db world_data --collection earthquakes    --type json --file earthquakes_fixed.geojson     --jsonArray
mongoimport --db world_data --collection cities         --type json --file world_cities_fixed.geojson    --jsonArray
mongoimport --db world_data --collection states         --type json --file state_borders_fixed.geojson   --jsonArray
mongoimport --db world_data --collection terrorism      --type json --file globalterrorism_fixed.geojson --jsonArray